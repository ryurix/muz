enum Environment {
    DEVELOPMENT = 'development',
    PRODUCTION = 'production'
}

export default Environment;