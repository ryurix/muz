import ClassNames from '../Config/ClassNames';

const arrow = (_, classNames: ClassNames) => `<div class="${classNames.arrow}" role="presentation"></div>`;

export default arrow;