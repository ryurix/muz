type ICallback = () => void;

export default ICallback;