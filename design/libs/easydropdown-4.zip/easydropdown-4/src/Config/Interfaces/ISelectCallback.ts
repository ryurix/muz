type ISelectCallback = (value?: string) => void;

export default ISelectCallback;