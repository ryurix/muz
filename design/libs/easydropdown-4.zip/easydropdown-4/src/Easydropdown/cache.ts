import Easydropdown from './Easydropdown';

const cache: Easydropdown[] = [];

export default cache;