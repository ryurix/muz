enum AttributeChangeType {
    ADD = 'ADD',
    EDIT = 'EDIT',
    REMOVE = 'REMOVE'
}

export default AttributeChangeType;