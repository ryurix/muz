export enum DomChangeType {
    NONE    = 'NONE',
    FULL    = 'FULL',
    REPLACE = 'REPLACE',
    INNER   = 'INNER',
    OUTER   = 'OUTER'
}

export default DomChangeType;