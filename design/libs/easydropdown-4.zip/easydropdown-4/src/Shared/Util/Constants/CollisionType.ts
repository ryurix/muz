enum CollisionType {
    NONE   = 'NONE',
    TOP    = 'TOP',
    BOTTOM = 'BOTTOM'
}

export default CollisionType;