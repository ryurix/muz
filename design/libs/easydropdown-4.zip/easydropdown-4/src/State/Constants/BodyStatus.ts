enum BodyStatus {
    CLOSED     = 'CLOSED',
    OPEN_ABOVE = 'OPEN_ABOVE',
    OPEN_BELOW = 'OPEN_BELOW'
}

export default BodyStatus;