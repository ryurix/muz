enum ScrollStatus {
    AT_TOP    = 'AT_TOP',
    SCROLLED  = 'SCROLLED',
    AT_BOTTOM = 'AT_BOTTOM'
}

export default ScrollStatus;