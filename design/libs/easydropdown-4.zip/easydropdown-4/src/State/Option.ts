class Option {
    public label:      string  = '';
    public value:      string  = '';
    public isDisabled: boolean = false;
}

export default Option;