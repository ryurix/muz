import 'custom-event-polyfill';

import './Shared/Polyfills/Element.matches';

export {default as default} from './Easydropdown/factory';