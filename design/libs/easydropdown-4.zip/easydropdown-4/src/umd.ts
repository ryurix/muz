import 'custom-event-polyfill';

import './Shared/Polyfills/Element.matches';

import factory from './Easydropdown/factory';

module.exports = factory;